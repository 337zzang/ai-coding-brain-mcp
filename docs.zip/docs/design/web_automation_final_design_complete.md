
# 웹 자동화 시스템 최종 설계 문서 v2.0

## 📋 Executive Summary

현재 Thread 기반 웹 자동화 시스템을 **Client-Server 아키텍처**로 전환하여 세션 공유, ID 기반 추적, 크로스 프로세스 재연결을 구현합니다.

### 핵심 개선 사항
- **아키텍처**: Thread → Client-Server (독립 프로세스)
- **세션 관리**: BrowserManager 중앙 집중식
- **추적성**: 세션 ID 기반 구조화 로깅
- **안정성**: 프로세스 격리, 자동 복구

## 🎯 시스템 요구사항

### 기능적 요구사항
1. **세션 관리**
   - 고유 ID로 브라우저 인스턴스 식별
   - 여러 REPL/프로세스에서 동일 브라우저 재사용
   - 세션 정보 영속화 (재시작 후 복구)

2. **활동 추적**
   - 모든 액션을 세션 ID와 함께 로깅
   - JSONL 형식 활동 기록
   - 실시간 모니터링 지원

3. **에러 처리**
   - 브라우저 크래시 감지 및 자동 재시작
   - 고아 프로세스 정리
   - 연결 끊김 시 재연결

### 비기능적 요구사항
- **성능**: 100+ 동시 세션 지원
- **안정성**: 24/7 운영 가능
- **호환성**: Windows/Linux/Mac 지원
- **확장성**: 수평 확장 가능

## 🏗️ 시스템 아키텍처

### 1. 컴포넌트 다이어그램

```mermaid
graph TB
    subgraph "Client Layer"
        C1[REPL Client 1]
        C2[REPL Client 2]
        CN[REPL Client N]
    end

    subgraph "Management Layer"
        BM[BrowserManager]
        SR[SessionRegistry]
        AL[ActivityLogger]
        HM[HealthMonitor]
    end

    subgraph "Browser Layer"
        B1[Browser Process 1<br/>session_1]
        B2[Browser Process 2<br/>session_2]
        BN[Browser Process N<br/>session_N]
    end

    subgraph "Storage Layer"
        JSON[(sessions.json)]
        LOGS[(Activity Logs)]
        PROF[(Browser Profiles)]
    end

    C1 & C2 & CN --> BM
    BM --> SR
    BM --> AL
    BM --> HM
    BM --> B1 & B2 & BN
    SR --> JSON
    AL --> LOGS
    B1 & B2 & BN --> PROF
```

### 2. 시퀀스 다이어그램

```mermaid
sequenceDiagram
    participant C1 as Client 1
    participant BM as BrowserManager
    participant SR as SessionRegistry
    participant BP as Browser Process
    participant C2 as Client 2

    C1->>BM: create_session("user123")
    BM->>BP: launch_server()
    BP-->>BM: ws_endpoint
    BM->>SR: save_session(info)
    BM-->>C1: SessionInfo

    C1->>BM: connect("user123")
    BM->>SR: get_session("user123")
    SR-->>BM: session_info
    BM->>BP: playwright.connect(ws_endpoint)
    BP-->>BM: Browser instance
    BM-->>C1: Browser

    Note over C1: 작업 수행

    C2->>BM: connect("user123")
    Note over C2: 동일 브라우저 재사용
```

## 💻 구현 설계

### 1. BrowserManager (핵심 관리자)

```python
import os
import json
import subprocess
import logging
from datetime import datetime
from typing import Dict, Optional, List
from dataclasses import dataclass, asdict
from playwright.sync_api import sync_playwright, Browser
import psutil  # 프로세스 관리용

@dataclass
class SessionInfo:
    session_id: str
    pid: int
    ws_endpoint: str
    created_at: str
    last_activity: str
    status: str  # "active", "terminated", "orphan"
    browser_type: str = "chromium"
    headless: bool = False
    profile_dir: Optional[str] = None
    log_file: Optional[str] = None

class BrowserManager:
    """중앙 집중식 브라우저 관리자"""

    def __init__(self, base_dir: str = "browser_sessions"):
        self.base_dir = os.path.abspath(base_dir)
        self.registry = SessionRegistry(self.base_dir)
        self.logger = self._setup_logger()
        self._ensure_directories()
        self._recover_orphans()

    def _ensure_directories(self):
        """필수 디렉토리 생성"""
        dirs = ["profiles", "logs", "activities", "traces"]
        for dir_name in dirs:
            os.makedirs(os.path.join(self.base_dir, dir_name), exist_ok=True)

    def _setup_logger(self) -> logging.Logger:
        """로거 설정"""
        logger = logging.getLogger("BrowserManager")
        logger.setLevel(logging.INFO)

        # 파일 핸들러
        fh = logging.FileHandler(
            os.path.join(self.base_dir, "manager.log")
        )
        fh.setFormatter(logging.Formatter(
            '[%(asctime)s] [%(levelname)s] %(message)s'
        ))
        logger.addHandler(fh)

        return logger

    def create_session(self, 
                      session_id: str,
                      browser_type: str = "chromium",
                      headless: bool = False,
                      **kwargs) -> SessionInfo:
        """새 브라우저 서버 시작"""

        # 기존 세션 확인
        existing = self.registry.get_session(session_id)
        if existing and self._is_alive(existing.pid):
            self.logger.warning(f"Session {session_id} already exists")
            return existing

        # 프로필 디렉토리
        profile_dir = os.path.join(self.base_dir, "profiles", session_id)
        os.makedirs(profile_dir, exist_ok=True)

        # 브라우저 서버 시작
        ws_endpoint, pid = self._launch_browser_server(
            browser_type, headless, profile_dir, **kwargs
        )

        # 세션 정보 생성
        session_info = SessionInfo(
            session_id=session_id,
            pid=pid,
            ws_endpoint=ws_endpoint,
            created_at=datetime.now().isoformat(),
            last_activity=datetime.now().isoformat(),
            status="active",
            browser_type=browser_type,
            headless=headless,
            profile_dir=profile_dir,
            log_file=os.path.join(self.base_dir, "logs", f"{session_id}.log")
        )

        # 레지스트리에 저장
        self.registry.save_session(session_info)

        # 활동 로거 초기화
        activity_logger = ActivityLogger(session_id, self.base_dir)
        activity_logger.log_action("session_created", {
            "browser_type": browser_type,
            "headless": headless
        })

        self.logger.info(f"Created session {session_id} with PID {pid}")
        return session_info

    def _launch_browser_server(self, 
                              browser_type: str,
                              headless: bool,
                              profile_dir: str,
                              **kwargs) -> tuple[str, int]:
        """브라우저 서버 프로세스 시작"""

        # 명령어 구성
        cmd = [
            "npx", "playwright", "launch-server",
            f"--browser={browser_type}",
            "--port=0"  # 자동 포트 할당
        ]

        if not headless:
            cmd.append("--no-headless")

        # Windows 특별 처리
        if os.name == 'nt':
            creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            creation_flags = 0

        # 프로세스 시작
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            creationflags=creation_flags,
            cwd=self.base_dir
        )

        # WebSocket 엔드포인트 읽기
        ws_endpoint = None
        for line in process.stdout:
            if "ws://" in line:
                # 엔드포인트 추출
                import re
                match = re.search(r'ws://[^\s]+', line)
                if match:
                    ws_endpoint = match.group()
                    break

        if not ws_endpoint:
            process.terminate()
            raise RuntimeError("Failed to get WebSocket endpoint")

        return ws_endpoint, process.pid

    def connect(self, session_id: str) -> Optional[Browser]:
        """기존 브라우저에 연결"""

        session_info = self.registry.get_session(session_id)
        if not session_info:
            self.logger.error(f"Session {session_id} not found")
            return None

        if not self._is_alive(session_info.pid):
            self.logger.error(f"Session {session_id} process is dead")
            self.registry.update_status(session_id, "terminated")
            return None

        try:
            # Playwright 연결
            playwright = sync_playwright().start()
            browser = playwright.chromium.connect(session_info.ws_endpoint)

            # 활동 시간 업데이트
            self.registry.update_activity(session_id)

            # 활동 로깅
            activity_logger = ActivityLogger(session_id, self.base_dir)
            activity_logger.log_action("connected", {})

            self.logger.info(f"Connected to session {session_id}")
            return browser

        except Exception as e:
            self.logger.error(f"Failed to connect to {session_id}: {e}")
            return None

    def terminate_session(self, session_id: str, force: bool = False):
        """브라우저 종료"""

        session_info = self.registry.get_session(session_id)
        if not session_info:
            return

        # 프로세스 종료
        if self._is_alive(session_info.pid):
            try:
                process = psutil.Process(session_info.pid)
                if force:
                    process.kill()
                else:
                    process.terminate()
                process.wait(timeout=5)
            except Exception as e:
                self.logger.error(f"Failed to terminate {session_id}: {e}")

        # 레지스트리 업데이트
        self.registry.update_status(session_id, "terminated")

        # 활동 로깅
        activity_logger = ActivityLogger(session_id, self.base_dir)
        activity_logger.log_action("session_terminated", {"force": force})

        self.logger.info(f"Terminated session {session_id}")

    def list_sessions(self, active_only: bool = True) -> List[SessionInfo]:
        """세션 목록 조회"""

        sessions = self.registry.list_sessions()

        if active_only:
            # 활성 세션만 필터링
            active_sessions = []
            for session in sessions:
                if self._is_alive(session.pid):
                    active_sessions.append(session)
                else:
                    # 죽은 세션 상태 업데이트
                    self.registry.update_status(session.session_id, "terminated")

            return active_sessions

        return sessions

    def _is_alive(self, pid: int) -> bool:
        """프로세스 생존 확인"""
        try:
            process = psutil.Process(pid)
            return process.is_running()
        except psutil.NoSuchProcess:
            return False

    def _recover_orphans(self):
        """고아 프로세스 복구"""

        orphans = self.registry.find_orphans()
        for session_info in orphans:
            if self._is_alive(session_info.pid):
                # 프로세스가 살아있으면 복구
                self.registry.update_status(session_info.session_id, "active")
                self.logger.info(f"Recovered orphan session {session_info.session_id}")
            else:
                # 죽은 프로세스는 정리
                self.registry.update_status(session_info.session_id, "terminated")
                self.logger.info(f"Cleaned dead session {session_info.session_id}")
```

### 2. SessionRegistry (영속화 계층)

```python
class SessionRegistry:
    """세션 정보 영속화 관리"""

    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.sessions_file = os.path.join(base_dir, "sessions.json")
        self.sessions: Dict[str, SessionInfo] = {}
        self._load_sessions()

    def _load_sessions(self):
        """파일에서 세션 정보 로드"""
        if os.path.exists(self.sessions_file):
            try:
                with open(self.sessions_file, 'r') as f:
                    data = json.load(f)
                    for sid, info in data.items():
                        self.sessions[sid] = SessionInfo(**info)
            except Exception as e:
                logging.error(f"Failed to load sessions: {e}")
                self.sessions = {}

    def _save_sessions(self):
        """세션 정보를 파일에 저장"""
        data = {
            sid: asdict(info) 
            for sid, info in self.sessions.items()
        }
        with open(self.sessions_file, 'w') as f:
            json.dump(data, f, indent=2)

    def save_session(self, session_info: SessionInfo):
        """세션 저장"""
        self.sessions[session_info.session_id] = session_info
        self._save_sessions()

    def get_session(self, session_id: str) -> Optional[SessionInfo]:
        """세션 조회"""
        return self.sessions.get(session_id)

    def update_status(self, session_id: str, status: str):
        """상태 업데이트"""
        if session_id in self.sessions:
            self.sessions[session_id].status = status
            self._save_sessions()

    def update_activity(self, session_id: str):
        """활동 시간 업데이트"""
        if session_id in self.sessions:
            self.sessions[session_id].last_activity = datetime.now().isoformat()
            self._save_sessions()

    def list_sessions(self) -> List[SessionInfo]:
        """전체 세션 목록"""
        return list(self.sessions.values())

    def find_orphans(self) -> List[SessionInfo]:
        """고아 세션 찾기"""
        orphans = []
        for session in self.sessions.values():
            if session.status == "active":
                # 매니저 재시작 후 모든 활성 세션은 잠재적 고아
                orphans.append(session)
        return orphans
```

### 3. ActivityLogger (활동 추적)

```python
class ActivityLogger:
    """세션별 활동 로깅"""

    def __init__(self, session_id: str, base_dir: str):
        self.session_id = session_id
        self.activity_file = os.path.join(
            base_dir, "activities", f"{session_id}.jsonl"
        )

    def log_action(self, action: str, details: dict):
        """활동 기록"""
        record = {
            "timestamp": datetime.now().isoformat(),
            "session_id": self.session_id,
            "action": action,
            "details": details
        }

        # JSONL 형식으로 추가
        with open(self.activity_file, 'a') as f:
            f.write(json.dumps(record) + '\n')

    def get_activities(self, limit: int = 100) -> List[dict]:
        """최근 활동 조회"""
        if not os.path.exists(self.activity_file):
            return []

        activities = []
        with open(self.activity_file, 'r') as f:
            lines = f.readlines()
            for line in lines[-limit:]:
                activities.append(json.loads(line))

        return activities
```

## 🚀 구현 로드맵

### Phase 1: MVP (1주)
- [x] 아키텍처 설계
- [ ] BrowserManager 핵심 기능
- [ ] launch_server() 구현
- [ ] 기본 세션 관리
- [ ] 단순 로깅

### Phase 2: 안정화 (2주)
- [ ] Windows 특화 처리
- [ ] 에러 처리 강화
- [ ] 헬스 체크
- [ ] 고아 프로세스 관리
- [ ] 테스트 suite

### Phase 3: 고도화 (3주)
- [ ] 성능 최적화
- [ ] 메트릭 수집
- [ ] 모니터링 대시보드
- [ ] API 서버
- [ ] 문서화

## 📝 사용 예제

```python
# REPL 1: 브라우저 시작
manager = BrowserManager()
session = manager.create_session("user123")
browser = manager.connect("user123")
page = browser.new_page()
page.goto("https://example.com")

# REPL 2: 동일 브라우저 재사용
manager2 = BrowserManager()  # 다른 인스턴스
browser2 = manager2.connect("user123")  # 기존 브라우저 연결
page2 = browser2.pages[0]  # 기존 페이지 접근
page2.click("button#submit")

# 활동 조회
logger = ActivityLogger("user123", "browser_sessions")
activities = logger.get_activities(10)
for activity in activities:
    print(f"[{activity['timestamp']}] {activity['action']}")

# 세션 종료
manager.terminate_session("user123")
```

## ⚠️ 주의사항

1. **보안**
   - WebSocket 엔드포인트는 로컬호스트만 허용
   - 프로덕션 환경에서는 인증 토큰 추가 고려

2. **리소스 관리**
   - 장시간 미사용 세션 자동 종료
   - 메모리 사용량 모니터링

3. **에러 처리**
   - 모든 외부 호출에 try-except
   - 적절한 로깅과 알림

## 📚 참고 자료
- [Playwright Browser Server](https://playwright.dev/docs/api/class-browsertype#browser-type-launch-server)
- [Python subprocess](https://docs.python.org/3/library/subprocess.html)
- [psutil](https://github.com/giampaolo/psutil)
