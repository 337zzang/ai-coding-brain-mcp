"""
Context 자동 기록을 위한 데코레이터
"""
from .auto_record import auto_record

__all__ = ['auto_record']
