"""
백업 유틸리티 (더미 구현)
"""

def create_backup(file_path):
    """백업 생성"""
    pass

def restore_backup(backup_path):
    """백업 복원"""
    pass

def list_backups():
    """백업 목록"""
    return []

def cleanup_old_backups():
    """오래된 백업 정리"""
    pass
